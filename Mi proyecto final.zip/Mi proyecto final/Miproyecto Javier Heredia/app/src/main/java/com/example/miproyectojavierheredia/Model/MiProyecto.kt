package com.example.miproyectojavierheredia.Model

data class ComparacionResultado(val sonIguales: Boolean)

